import json

# 1. Read the predictions file
with open("predictions.json", "r") as f:
    predictions = json.load(f)

ranked_queue = []

# 2. Score each image
for item in predictions:
    image_id = item["image_id"]
    boxes = item.get("boxes", [])

    if len(boxes) == 0:
        continue

    # Get average confidence score across all boxes in the image
    confidences = [b["confidence"] for b in boxes]
    avg_conf = sum(confidences) / len(confidences)

    # Uncertainty: low confidence = high uncertainty score (high priority to review)
    priority_score = round(1.0 - avg_conf, 2)

    ranked_queue.append({
        "image_id": image_id,
        "priority_score": priority_score,
        "reason": "low_confidence",
        "avg_confidence": round(avg_conf, 2)
    })

# 3. Sort highest priority first (most uncertain images at the top)
ranked_queue.sort(key=lambda x: x["priority_score"], reverse=True)

# 4. Save the result to ranked_queue.json
with open("ranked_queue.json", "w") as f:
    json.dump(ranked_queue, f, indent=2)

print(" SUCCESS! Created ranked_queue.json")
print("\nTop 3 most uncertain images to review first:")
for item in ranked_queue[:3]:
    print(f"  - {item['image_id']}: Priority {item['priority_score']} (Confidence {item['avg_confidence']})")